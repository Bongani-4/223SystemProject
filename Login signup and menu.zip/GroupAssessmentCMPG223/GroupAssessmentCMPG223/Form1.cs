﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupAssessmentCMPG223
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        string order = "";
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cbxMD.Checked = false;
            cbxBaby.Checked = false;
            cbxCalamari.Checked = false;
            cbxBigBoy.Checked = false;
            cbxCAT.Checked = false;
            cbxCheese.Checked = false;
            cbxChicken.Checked = false;
            cbxChickenNug.Checked = false;
            cbxChickMayo.Checked = false;
            cbxChips.Checked = false;
            cbxCoke.Checked = false;
            cbxDagwood.Checked = false;
            cbxFour.Checked = false;
            cbxHAC.Checked = false;
            cbxHCT.Checked = false;
            cbxHotdog.Checked = false;
            cbxLemon.Checked = false;
            cbxMargherita.Checked = false;
            cbxMashed.Checked = false;
            cbxMayo.Checked = false;
            cbxMeaty.Checked = false;
            cbxVeg.Checked=false; ;
            cbxThree.Checked = false;
            cbxTenders.Checked = false;
            cbxRib.Checked = false;
            cbxPepsi.Checked = false;
            cbxMediter.Checked = false;

            nudBaby.Value = 0;
            nudBigBoy.Value = 0;
            nudCalamari.Value = 0;
            nudCAT.Value = 0;
            nudCheese.Value = 0;
            nudChicken.Value = 0;
            nudChickenNug.Value = 0;
            nudChickMayo.Value = 0;
            nudChips.Value = 0;
            nudCoke.Value = 0;
            nudDagwood.Value = 0;
            nudFour.Value = 0;
            nudHAC.Value = 0;
            nudHCT.Value = 0;
            nudHotdog.Value = 0;
            nudLemon.Value = 0;
            nudMargherita.Value = 0;
            nudMashed.Value = 0;
            nudMayo.Value = 0;
            nudMeaty.Value = 0;
            nudMD.Value = 0;
            nudMediteranean.Value = 0;
            nudPepsi.Value = 0;
            nudRib.Value = 0;
            nudTenders.Value = 0;
            nudThree.Value = 0;
            nudVeg.Value = 0;


            order = "";
        }

        private void cbxBaby_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxBaby.Checked)
            {
                order = order + " " + cbxBaby.Text;
            }
            else if (order.Contains(cbxBaby.Text))
            {
                order = order.Replace(cbxBaby.Text, "");
            }
        }

        private void cbxChickenNug_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxChickenNug.Checked)
            {
                order = order + " " + cbxChickenNug.Text;
            }
            else if (order.Contains(cbxChickenNug.Text))
            {
                order = order.Replace(cbxChickenNug.Text, "");
            }
        }

        private void cbxHotdog_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxHotdog.Checked)
            {
                order = order + " " + cbxHotdog.Text;
            }
            else if (order.Contains(cbxHotdog.Text))
            {
                order = order.Replace(cbxHotdog.Text, "");
            }
        }

        private void cbxChips_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxChips.Checked)
            {
                order = order + " " + cbxChips.Text;
            }
            else if (order.Contains(cbxChips.Text))
            {
                order = order.Replace(cbxChips.Text, "");
            }
        }

        private void cbxMashed_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxMashed.Checked)
            {
                order = order + " " + cbxMashed.Text;
            }
            else if (order.Contains(cbxMashed.Text))
            {
                order = order.Replace(cbxMashed.Text, "");
            }
        }

        private void cbxTenders_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxTenders.Checked)
            {
                order = order + " " + cbxTenders.Text;
            }
            else if (order.Contains(cbxTenders.Text))
            {
                order = order.Replace(cbxTenders.Text, "");
            }
        }

        private void cbxMeaty_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxMeaty.Checked)
            {
                order = order + " " + cbxMeaty.Text;
            }
            else if (order.Contains(cbxMeaty.Text))
            {
                order = order.Replace(cbxMeaty.Text, "");
            }
        }

        private void cbxMayo_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxMayo.Checked)
            {
                order = order + " " + cbxMayo.Text;
            }
            else if (order.Contains(cbxMayo.Text))
            {
                order = order.Replace(cbxMayo.Text, "");
            }
        }

        private void cbxFour_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxFour.Checked)
            {
                order = order + " " + cbxFour.Text;
            }
            else if (order.Contains(cbxFour.Text))
            {
                order = order.Replace(cbxFour.Text, "");
            }
        }

        private void cbxMargherita_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxMargherita.Checked)
            {
                order = order + " " + cbxMargherita.Text;
            }
            else if (order.Contains(cbxMargherita.Text))
            {
                order = order.Replace(cbxMargherita.Text, "");
            }
        }

        private void cbxThree_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxThree.Checked)
            {
                order = order + " " + cbxThree.Text;
            }
            else if (order.Contains(cbxThree.Text))
            {
                order = order.Replace(cbxThree.Text, "");
            }
        }

        private void cbxCalamari_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxCalamari.Checked)
            {
                order = order + " " + cbxCalamari.Text;
            }
            else if (order.Contains(cbxCalamari.Text))
            {
                order = order.Replace(cbxCalamari.Text, "");
            }
        }

        private void cbxChickMayo_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxChickMayo.Checked)
            {
                order = order + " " + cbxChickMayo.Text;
            }
            else if (order.Contains(cbxChickMayo.Text))
            {
                order = order.Replace(cbxChickMayo.Text, "");
            }
        }

        private void cbxHAC_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxHAC.Checked)
            {
                order = order + " " + cbxHAC.Text;
            }
            else if (order.Contains(cbxHAC.Text))
            {
                order = order.Replace(cbxHAC.Text, "");
            }
        }

        private void cbxCheese_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxCheese.Checked)
            {
                order = order + " " + cbxCheese.Text;
            }
            else if (order.Contains(cbxCheese.Text))
            {
                order = order.Replace(cbxCheese.Text, "");
            }
        }

        private void cbxCAT_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxCAT.Checked)
            {
                order = order + " " + cbxCAT.Text;
            }
            else if (order.Contains(cbxCAT.Text))
            {
                order = order.Replace(cbxCAT.Text, "");
            }
        }

        private void cbxHCT_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxHCT.Checked)
            {
                order = order + " " + cbxHCT.Text;
            }
            else if (order.Contains(cbxHCT.Text))
            {
                order = order.Replace(cbxHCT.Text, "");
            }
        }

        private void cbxDagwood_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxDagwood.Checked)
            {
                order = order + " " + cbxDagwood.Text;
            }
            else if (order.Contains(cbxDagwood.Text))
            {
                order=order.Replace(cbxDagwood.Text, "");
            }
        }

        private void cbxMediter_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxMediter.Checked)
            {
                order = order + " " + cbxMediter.Text;
            }
            else if (order.Contains(cbxMediter.Text))
            {
                order = order.Replace(cbxMediter.Text, "");
            }
        }

        private void cbxMD_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxMD.Checked)
            {
                order = order + " " + cbxMD.Text;
            }
            else if (order.Contains(cbxMD.Text))
            {
                order = order.Replace(cbxMD.Text, "");
            }
        }

        private void cbxPepsi_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxPepsi.Checked)
            {
                order = order + " " + cbxPepsi.Text;
            }
            else if (order.Contains(cbxPepsi.Text))
            {
                order = order.Replace(cbxPepsi.Text, "");
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void cbxLemon_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxLemon.Checked)
            {
                order = order + " " + cbxLemon.Text;
            }
            else if (order.Contains(cbxLemon.Text))
            {
                order = order.Replace(cbxLemon.Text, "");
            }
        }

        private void cbxCoke_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxCoke.Checked)
            {
                order = order + " " + cbxCoke.Text;
            }
            else if (order.Contains(cbxCoke.Text))
            {
                order = order.Replace(cbxCoke.Text, "");
            }
        }

        private void cbxBigBoy_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxBigBoy.Checked)
            {
                order = order + " " + cbxBigBoy.Text;
            }
            else if (order.Contains(cbxBigBoy.Text))
            {
                order = order.Replace(cbxBigBoy.Text, "");
            }
        }

        private void cbxVeg_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxVeg.Checked)
             {
                 order = order +" " +cbxVeg.Text;
             }
            else if (order.Contains(cbxVeg.Text))
            {
                order = order.Replace(cbxVeg.Text, "");
            }
        }

        private void cbxChicken_CheckedChanged(object sender, EventArgs e)
        {
             if (cbxChicken.Checked)
             {
                  order = order + " " + cbxChicken.Text;
             }
            else if (order.Contains(cbxChicken.Text))
            {
                order = order.Replace(cbxChicken.Text, "");
            }
        }
        private void cbxRib_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxRib.Checked)
            {
                order = order + " " + cbxRib.Text;

            }
            else if (order.Contains(cbxRib.Text))
            {
                order = order.Replace(cbxRib.Text, "");

            }
            
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {

            if (order.Contains(cbxMD.Text))
            {
                order = order.Replace(cbxMD.Text, cbxMD.Text + " x" + nudMD.Value.ToString());

            }

            if (order.Contains(cbxPepsi.Text))
            {
                order = order.Replace(cbxPepsi.Text, cbxPepsi.Text + " x" + nudPepsi.Value.ToString());

            }

            if (order.Contains(cbxLemon.Text))
            {
                order = order.Replace(cbxLemon.Text, cbxLemon.Text + " x" + nudLemon.Value.ToString());

            }

            if (order.Contains(cbxCoke.Text))
            {
                order = order.Replace(cbxCoke.Text, cbxCoke.Text + " x" + nudCoke.Value.ToString());

            }

            if (order.Contains(cbxBaby.Text))
            {
                order = order.Replace(cbxBaby.Text, cbxBaby.Text + " x" + nudBaby.Value.ToString());

            }
            if (order.Contains(cbxChickenNug.Text))
            {
                order = order.Replace(cbxChickenNug.Text, cbxChickenNug.Text + " x" + nudChickenNug.Value.ToString());

            }

            if (order.Contains(cbxHotdog.Text))
            {
                order = order.Replace(cbxHotdog.Text, cbxHotdog.Text + " x" + nudHotdog.Value.ToString());

            }

            if (order.Contains(cbxChips.Text))
            {
                order = order.Replace(cbxChips.Text, cbxChips.Text + " x" + nudChips.Value.ToString());

            }
            if (order.Contains(cbxMashed.Text))
            {
                order = order.Replace(cbxMashed.Text, cbxMashed.Text + " x" + nudMashed.Value.ToString());

            }
            if (order.Contains(cbxTenders.Text))
            {
                order = order.Replace(cbxTenders.Text, cbxTenders.Text + " x" + nudTenders.Value.ToString());

            }


            if (order.Contains(cbxBigBoy.Text))
            {
                order = order.Replace(cbxBigBoy.Text, cbxBigBoy.Text + " x" + nudBigBoy.Value.ToString());

            }

            if (order.Contains(cbxVeg.Text))
            {
                order = order.Replace(cbxVeg.Text, cbxVeg.Text + " x" + nudVeg.Value.ToString());

            }


            if (order.Contains(cbxChicken.Text))
            {
                order = order.Replace(cbxChicken.Text, cbxChicken.Text + " x" + nudChicken.Value.ToString());

            }


            if (order.Contains(cbxRib.Text))
            {
                order = order.Replace(cbxRib.Text, cbxRib.Text + " x" + nudRib.Value.ToString());

            }


            if (order.Contains(cbxMeaty.Text))
            {
                order = order.Replace(cbxMeaty.Text, cbxMeaty.Text + " x" + nudMeaty.Value.ToString());

            }


            if (order.Contains(cbxMayo.Text))
            {
                order = order.Replace(cbxMayo.Text, cbxMayo.Text + " x" + nudMayo.Value.ToString());

            }



            if (order.Contains(cbxFour.Text))
            {
                order = order.Replace(cbxFour.Text, cbxFour.Text + " x" + nudFour.Value.ToString());

            }



            if (order.Contains(cbxMargherita.Text))
            {
                order = order.Replace(cbxMargherita.Text, cbxMargherita.Text + " x" + nudMargherita.Value.ToString());

            }

            if (order.Contains(cbxThree.Text))
            {
                order = order.Replace(cbxThree.Text, cbxThree.Text + " x" + nudThree.Value.ToString());

            }



            if (order.Contains(cbxCalamari.Text))
            {
                order = order.Replace(cbxCalamari.Text, cbxCalamari.Text + " x" + nudCalamari.Value.ToString());

            }




            if (order.Contains(cbxChickMayo.Text))
            {
                order = order.Replace(cbxChickMayo.Text, cbxChickMayo.Text + " x" + nudChickMayo.Value.ToString());

            }




            if (order.Contains(cbxHAC.Text))
            {
                order = order.Replace(cbxHAC.Text, cbxHAC.Text + " x" + nudHAC.Value.ToString());

            }


            if (order.Contains(cbxCheese.Text))
            {
                order = order.Replace(cbxCheese.Text, cbxCheese.Text + " x" + nudCheese.Value.ToString());

            }


            if (order.Contains(cbxCAT.Text))
            {
                order = order.Replace(cbxCAT.Text, cbxCAT.Text + " x" + nudCAT.Value.ToString());

            }


            if (order.Contains(cbxHCT.Text))
            {
                order = order.Replace(cbxHCT.Text, cbxHCT.Text + " x" + nudHCT.Value.ToString());

            }

            if (order.Contains(cbxDagwood.Text))
            {
                order = order.Replace(cbxDagwood.Text, cbxDagwood.Text + " x" + nudDagwood.Value.ToString());

            }


            if (order.Contains(cbxMediter.Text))
            {
                order = order.Replace(cbxMediter.Text, cbxMediter.Text + " x" + nudMediteranean.Value.ToString());
            }


            MessageBox.Show("Your order has been placed successfully, it is as follows: "+order);
        }
    }
}
