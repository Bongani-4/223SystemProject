﻿namespace GroupAssessmentCMPG223
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenu));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.cbxBigBoy = new System.Windows.Forms.CheckBox();
            this.cbxVeg = new System.Windows.Forms.CheckBox();
            this.cbxChicken = new System.Windows.Forms.CheckBox();
            this.cbxRib = new System.Windows.Forms.CheckBox();
            this.nudBigBoy = new System.Windows.Forms.NumericUpDown();
            this.nudVeg = new System.Windows.Forms.NumericUpDown();
            this.nudChicken = new System.Windows.Forms.NumericUpDown();
            this.nudRib = new System.Windows.Forms.NumericUpDown();
            this.nudChips = new System.Windows.Forms.NumericUpDown();
            this.nudHotdog = new System.Windows.Forms.NumericUpDown();
            this.nudChickenNug = new System.Windows.Forms.NumericUpDown();
            this.nudBaby = new System.Windows.Forms.NumericUpDown();
            this.cbxChips = new System.Windows.Forms.CheckBox();
            this.cbxHotdog = new System.Windows.Forms.CheckBox();
            this.cbxChickenNug = new System.Windows.Forms.CheckBox();
            this.cbxBaby = new System.Windows.Forms.CheckBox();
            this.nudTenders = new System.Windows.Forms.NumericUpDown();
            this.nudMashed = new System.Windows.Forms.NumericUpDown();
            this.cbxTenders = new System.Windows.Forms.CheckBox();
            this.cbxMashed = new System.Windows.Forms.CheckBox();
            this.nudMargherita = new System.Windows.Forms.NumericUpDown();
            this.nudFour = new System.Windows.Forms.NumericUpDown();
            this.nudMayo = new System.Windows.Forms.NumericUpDown();
            this.nudMeaty = new System.Windows.Forms.NumericUpDown();
            this.cbxMargherita = new System.Windows.Forms.CheckBox();
            this.cbxFour = new System.Windows.Forms.CheckBox();
            this.cbxMayo = new System.Windows.Forms.CheckBox();
            this.cbxMeaty = new System.Windows.Forms.CheckBox();
            this.nudCalamari = new System.Windows.Forms.NumericUpDown();
            this.nudThree = new System.Windows.Forms.NumericUpDown();
            this.cbxCalamari = new System.Windows.Forms.CheckBox();
            this.cbxThree = new System.Windows.Forms.CheckBox();
            this.nudCAT = new System.Windows.Forms.NumericUpDown();
            this.nudCheese = new System.Windows.Forms.NumericUpDown();
            this.nudHAC = new System.Windows.Forms.NumericUpDown();
            this.nudChickMayo = new System.Windows.Forms.NumericUpDown();
            this.cbxCAT = new System.Windows.Forms.CheckBox();
            this.cbxCheese = new System.Windows.Forms.CheckBox();
            this.cbxHAC = new System.Windows.Forms.CheckBox();
            this.cbxChickMayo = new System.Windows.Forms.CheckBox();
            this.nudMediteranean = new System.Windows.Forms.NumericUpDown();
            this.nudDagwood = new System.Windows.Forms.NumericUpDown();
            this.nudHCT = new System.Windows.Forms.NumericUpDown();
            this.cbxMediter = new System.Windows.Forms.CheckBox();
            this.cbxDagwood = new System.Windows.Forms.CheckBox();
            this.cbxHCT = new System.Windows.Forms.CheckBox();
            this.nudCoke = new System.Windows.Forms.NumericUpDown();
            this.cbxPepsi = new System.Windows.Forms.CheckBox();
            this.nudLemon = new System.Windows.Forms.NumericUpDown();
            this.cbxMD = new System.Windows.Forms.CheckBox();
            this.nudPepsi = new System.Windows.Forms.NumericUpDown();
            this.cbxLemon = new System.Windows.Forms.CheckBox();
            this.nudMD = new System.Windows.Forms.NumericUpDown();
            this.cbxCoke = new System.Windows.Forms.CheckBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnPlaceOrder = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudBigBoy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVeg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChicken)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRib)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChips)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHotdog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChickenNug)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBaby)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTenders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMashed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMargherita)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMayo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMeaty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCalamari)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudThree)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCAT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCheese)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHAC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChickMayo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMediteranean)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDagwood)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHCT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCoke)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLemon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPepsi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMD)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(242, 239);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(46, 257);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(171, 44);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back to Home Screen";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SimSun", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(272, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 28);
            this.label1.TabIndex = 3;
            this.label1.Text = "Menu";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nudCoke);
            this.groupBox1.Controls.Add(this.cbxPepsi);
            this.groupBox1.Controls.Add(this.nudLemon);
            this.groupBox1.Controls.Add(this.cbxMD);
            this.groupBox1.Controls.Add(this.nudPepsi);
            this.groupBox1.Controls.Add(this.cbxLemon);
            this.groupBox1.Controls.Add(this.nudMD);
            this.groupBox1.Controls.Add(this.cbxCoke);
            this.groupBox1.Font = new System.Drawing.Font("SimSun", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(277, 43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(235, 180);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Drinks";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.nudTenders);
            this.groupBox2.Controls.Add(this.nudMashed);
            this.groupBox2.Controls.Add(this.cbxTenders);
            this.groupBox2.Controls.Add(this.cbxMashed);
            this.groupBox2.Controls.Add(this.nudChips);
            this.groupBox2.Controls.Add(this.nudHotdog);
            this.groupBox2.Controls.Add(this.nudChickenNug);
            this.groupBox2.Controls.Add(this.nudBaby);
            this.groupBox2.Controls.Add(this.cbxChips);
            this.groupBox2.Controls.Add(this.cbxHotdog);
            this.groupBox2.Controls.Add(this.cbxChickenNug);
            this.groupBox2.Controls.Add(this.cbxBaby);
            this.groupBox2.Font = new System.Drawing.Font("SimSun", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(277, 240);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(275, 253);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kiddies menu";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.nudRib);
            this.groupBox3.Controls.Add(this.cbxVeg);
            this.groupBox3.Controls.Add(this.nudChicken);
            this.groupBox3.Controls.Add(this.cbxBigBoy);
            this.groupBox3.Controls.Add(this.nudVeg);
            this.groupBox3.Controls.Add(this.cbxChicken);
            this.groupBox3.Controls.Add(this.nudBigBoy);
            this.groupBox3.Controls.Add(this.cbxRib);
            this.groupBox3.Font = new System.Drawing.Font("SimSun", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(518, 43);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(314, 180);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Burgers";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.nudCalamari);
            this.groupBox4.Controls.Add(this.nudThree);
            this.groupBox4.Controls.Add(this.cbxCalamari);
            this.groupBox4.Controls.Add(this.cbxThree);
            this.groupBox4.Controls.Add(this.nudMargherita);
            this.groupBox4.Controls.Add(this.nudFour);
            this.groupBox4.Controls.Add(this.nudMayo);
            this.groupBox4.Controls.Add(this.nudMeaty);
            this.groupBox4.Controls.Add(this.cbxMargherita);
            this.groupBox4.Controls.Add(this.cbxFour);
            this.groupBox4.Controls.Add(this.cbxMayo);
            this.groupBox4.Controls.Add(this.cbxMeaty);
            this.groupBox4.Font = new System.Drawing.Font("SimSun", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(558, 240);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(274, 265);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Pizza";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.nudMediteranean);
            this.groupBox5.Controls.Add(this.nudDagwood);
            this.groupBox5.Controls.Add(this.nudHCT);
            this.groupBox5.Controls.Add(this.cbxMediter);
            this.groupBox5.Controls.Add(this.cbxDagwood);
            this.groupBox5.Controls.Add(this.cbxHCT);
            this.groupBox5.Controls.Add(this.nudCAT);
            this.groupBox5.Controls.Add(this.nudCheese);
            this.groupBox5.Controls.Add(this.nudHAC);
            this.groupBox5.Controls.Add(this.nudChickMayo);
            this.groupBox5.Controls.Add(this.cbxCAT);
            this.groupBox5.Controls.Add(this.cbxCheese);
            this.groupBox5.Controls.Add(this.cbxHAC);
            this.groupBox5.Controls.Add(this.cbxChickMayo);
            this.groupBox5.Font = new System.Drawing.Font("SimSun", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(846, 43);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(293, 298);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Toasted Sandwiches";
            // 
            // cbxBigBoy
            // 
            this.cbxBigBoy.AutoSize = true;
            this.cbxBigBoy.Location = new System.Drawing.Point(16, 27);
            this.cbxBigBoy.Name = "cbxBigBoy";
            this.cbxBigBoy.Size = new System.Drawing.Size(148, 17);
            this.cbxBigBoy.TabIndex = 0;
            this.cbxBigBoy.Text = "Toothsome Big boy";
            this.cbxBigBoy.UseVisualStyleBackColor = true;
            this.cbxBigBoy.CheckedChanged += new System.EventHandler(this.cbxBigBoy_CheckedChanged);
            // 
            // cbxVeg
            // 
            this.cbxVeg.AutoSize = true;
            this.cbxVeg.Location = new System.Drawing.Point(16, 63);
            this.cbxVeg.Name = "cbxVeg";
            this.cbxVeg.Size = new System.Drawing.Size(148, 17);
            this.cbxVeg.TabIndex = 1;
            this.cbxVeg.Text = "Vegeterian Burger";
            this.cbxVeg.UseVisualStyleBackColor = true;
            this.cbxVeg.CheckedChanged += new System.EventHandler(this.cbxVeg_CheckedChanged);
            // 
            // cbxChicken
            // 
            this.cbxChicken.AutoSize = true;
            this.cbxChicken.Location = new System.Drawing.Point(16, 107);
            this.cbxChicken.Name = "cbxChicken";
            this.cbxChicken.Size = new System.Drawing.Size(127, 17);
            this.cbxChicken.TabIndex = 2;
            this.cbxChicken.Text = "Chicken Burger";
            this.cbxChicken.UseVisualStyleBackColor = true;
            this.cbxChicken.CheckedChanged += new System.EventHandler(this.cbxChicken_CheckedChanged);
            // 
            // cbxRib
            // 
            this.cbxRib.AutoSize = true;
            this.cbxRib.Location = new System.Drawing.Point(16, 147);
            this.cbxRib.Name = "cbxRib";
            this.cbxRib.Size = new System.Drawing.Size(141, 17);
            this.cbxRib.TabIndex = 3;
            this.cbxRib.Text = "Spare Rib Burger";
            this.cbxRib.UseVisualStyleBackColor = true;
            this.cbxRib.CheckedChanged += new System.EventHandler(this.cbxRib_CheckedChanged);
            // 
            // nudBigBoy
            // 
            this.nudBigBoy.Location = new System.Drawing.Point(208, 26);
            this.nudBigBoy.Name = "nudBigBoy";
            this.nudBigBoy.Size = new System.Drawing.Size(53, 22);
            this.nudBigBoy.TabIndex = 4;
        
            // 
            // nudVeg
            // 
            this.nudVeg.Location = new System.Drawing.Point(208, 65);
            this.nudVeg.Name = "nudVeg";
            this.nudVeg.Size = new System.Drawing.Size(53, 22);
            this.nudVeg.TabIndex = 5;

            // 
            // nudChicken
            // 
            this.nudChicken.Location = new System.Drawing.Point(208, 108);
            this.nudChicken.Name = "nudChicken";
            this.nudChicken.Size = new System.Drawing.Size(53, 22);
            this.nudChicken.TabIndex = 6;
        
            // 
            // nudRib
            // 
            this.nudRib.Location = new System.Drawing.Point(208, 147);
            this.nudRib.Name = "nudRib";
            this.nudRib.Size = new System.Drawing.Size(53, 22);
            this.nudRib.TabIndex = 7;
     
            // 
            // nudChips
            // 
            this.nudChips.Location = new System.Drawing.Point(175, 142);
            this.nudChips.Name = "nudChips";
            this.nudChips.Size = new System.Drawing.Size(53, 22);
            this.nudChips.TabIndex = 15;
  
            // 
            // nudHotdog
            // 
            this.nudHotdog.Location = new System.Drawing.Point(175, 103);
            this.nudHotdog.Name = "nudHotdog";
            this.nudHotdog.Size = new System.Drawing.Size(53, 22);
            this.nudHotdog.TabIndex = 14;
           
            // 
            // nudChickenNug
            // 
            this.nudChickenNug.Location = new System.Drawing.Point(174, 60);
            this.nudChickenNug.Name = "nudChickenNug";
            this.nudChickenNug.Size = new System.Drawing.Size(53, 22);
            this.nudChickenNug.TabIndex = 13;
            
            // 
            // nudBaby
            // 
            this.nudBaby.Location = new System.Drawing.Point(175, 21);
            this.nudBaby.Name = "nudBaby";
            this.nudBaby.Size = new System.Drawing.Size(53, 22);
            this.nudBaby.TabIndex = 12;
            
            // 
            // cbxChips
            // 
            this.cbxChips.AutoSize = true;
            this.cbxChips.Location = new System.Drawing.Point(6, 144);
            this.cbxChips.Name = "cbxChips";
            this.cbxChips.Size = new System.Drawing.Size(64, 17);
            this.cbxChips.TabIndex = 11;
            this.cbxChips.Text = "Chips";
            this.cbxChips.UseVisualStyleBackColor = true;
            this.cbxChips.CheckedChanged += new System.EventHandler(this.cbxChips_CheckedChanged);
            // 
            // cbxHotdog
            // 
            this.cbxHotdog.AutoSize = true;
            this.cbxHotdog.Location = new System.Drawing.Point(6, 104);
            this.cbxHotdog.Name = "cbxHotdog";
            this.cbxHotdog.Size = new System.Drawing.Size(71, 17);
            this.cbxHotdog.TabIndex = 10;
            this.cbxHotdog.Text = "Hotdog";
            this.cbxHotdog.UseVisualStyleBackColor = true;
            this.cbxHotdog.CheckedChanged += new System.EventHandler(this.cbxHotdog_CheckedChanged);
            // 
            // cbxChickenNug
            // 
            this.cbxChickenNug.AutoSize = true;
            this.cbxChickenNug.Location = new System.Drawing.Point(6, 60);
            this.cbxChickenNug.Name = "cbxChickenNug";
            this.cbxChickenNug.Size = new System.Drawing.Size(134, 17);
            this.cbxChickenNug.TabIndex = 9;
            this.cbxChickenNug.Text = "Chicken Nuggets";
            this.cbxChickenNug.UseVisualStyleBackColor = true;
            this.cbxChickenNug.CheckedChanged += new System.EventHandler(this.cbxChickenNug_CheckedChanged);
            // 
            // cbxBaby
            // 
            this.cbxBaby.AutoSize = true;
            this.cbxBaby.Location = new System.Drawing.Point(6, 21);
            this.cbxBaby.Name = "cbxBaby";
            this.cbxBaby.Size = new System.Drawing.Size(141, 17);
            this.cbxBaby.TabIndex = 8;
            this.cbxBaby.Text = "Babytooth Burger";
            this.cbxBaby.UseVisualStyleBackColor = true;
            this.cbxBaby.CheckedChanged += new System.EventHandler(this.cbxBaby_CheckedChanged);
            // 
            // nudTenders
            // 
            this.nudTenders.Location = new System.Drawing.Point(175, 219);
            this.nudTenders.Name = "nudTenders";
            this.nudTenders.Size = new System.Drawing.Size(53, 22);
            this.nudTenders.TabIndex = 21;
           
            // 
            // nudMashed
            // 
            this.nudMashed.Location = new System.Drawing.Point(175, 180);
            this.nudMashed.Name = "nudMashed";
            this.nudMashed.Size = new System.Drawing.Size(53, 22);
            this.nudMashed.TabIndex = 20;
           
            // 
            // cbxTenders
            // 
            this.cbxTenders.AutoSize = true;
            this.cbxTenders.Location = new System.Drawing.Point(6, 219);
            this.cbxTenders.Name = "cbxTenders";
            this.cbxTenders.Size = new System.Drawing.Size(134, 17);
            this.cbxTenders.TabIndex = 17;
            this.cbxTenders.Text = "Chicken Tenders";
            this.cbxTenders.UseVisualStyleBackColor = true;
            this.cbxTenders.CheckedChanged += new System.EventHandler(this.cbxTenders_CheckedChanged);
            // 
            // cbxMashed
            // 
            this.cbxMashed.AutoSize = true;
            this.cbxMashed.Location = new System.Drawing.Point(6, 180);
            this.cbxMashed.Name = "cbxMashed";
            this.cbxMashed.Size = new System.Drawing.Size(134, 17);
            this.cbxMashed.TabIndex = 16;
            this.cbxMashed.Text = "Mashed Potatoes";
            this.cbxMashed.UseVisualStyleBackColor = true;
            this.cbxMashed.CheckedChanged += new System.EventHandler(this.cbxMashed_CheckedChanged);
            // 
            // nudMargherita
            // 
            this.nudMargherita.Location = new System.Drawing.Point(171, 152);
            this.nudMargherita.Name = "nudMargherita";
            this.nudMargherita.Size = new System.Drawing.Size(53, 22);
            this.nudMargherita.TabIndex = 15;
           
            // 
            // nudFour
            // 
            this.nudFour.Location = new System.Drawing.Point(171, 113);
            this.nudFour.Name = "nudFour";
            this.nudFour.Size = new System.Drawing.Size(53, 22);
            this.nudFour.TabIndex = 14;
           
            // 
            // nudMayo
            // 
            this.nudMayo.Location = new System.Drawing.Point(171, 70);
            this.nudMayo.Name = "nudMayo";
            this.nudMayo.Size = new System.Drawing.Size(53, 22);
            this.nudMayo.TabIndex = 13;
            
            // 
            // nudMeaty
            // 
            this.nudMeaty.Location = new System.Drawing.Point(171, 31);
            this.nudMeaty.Name = "nudMeaty";
            this.nudMeaty.Size = new System.Drawing.Size(53, 22);
            this.nudMeaty.TabIndex = 12;
           
            // 
            // cbxMargherita
            // 
            this.cbxMargherita.AutoSize = true;
            this.cbxMargherita.Location = new System.Drawing.Point(18, 154);
            this.cbxMargherita.Name = "cbxMargherita";
            this.cbxMargherita.Size = new System.Drawing.Size(99, 17);
            this.cbxMargherita.TabIndex = 11;
            this.cbxMargherita.Text = "Margherita";
            this.cbxMargherita.UseVisualStyleBackColor = true;
            this.cbxMargherita.CheckedChanged += new System.EventHandler(this.cbxMargherita_CheckedChanged);
            // 
            // cbxFour
            // 
            this.cbxFour.AutoSize = true;
            this.cbxFour.Location = new System.Drawing.Point(18, 114);
            this.cbxFour.Name = "cbxFour";
            this.cbxFour.Size = new System.Drawing.Size(113, 17);
            this.cbxFour.TabIndex = 10;
            this.cbxFour.Text = "Four Seasons";
            this.cbxFour.UseVisualStyleBackColor = true;
            this.cbxFour.CheckedChanged += new System.EventHandler(this.cbxFour_CheckedChanged);
            // 
            // cbxMayo
            // 
            this.cbxMayo.AutoSize = true;
            this.cbxMayo.Location = new System.Drawing.Point(18, 70);
            this.cbxMayo.Name = "cbxMayo";
            this.cbxMayo.Size = new System.Drawing.Size(113, 17);
            this.cbxMayo.TabIndex = 9;
            this.cbxMayo.Text = "Chicken Mayo";
            this.cbxMayo.UseVisualStyleBackColor = true;
            this.cbxMayo.CheckedChanged += new System.EventHandler(this.cbxMayo_CheckedChanged);
            // 
            // cbxMeaty
            // 
            this.cbxMeaty.AutoSize = true;
            this.cbxMeaty.Location = new System.Drawing.Point(18, 31);
            this.cbxMeaty.Name = "cbxMeaty";
            this.cbxMeaty.Size = new System.Drawing.Size(106, 17);
            this.cbxMeaty.TabIndex = 8;
            this.cbxMeaty.Text = "Meaty Feast";
            this.cbxMeaty.UseVisualStyleBackColor = true;
            this.cbxMeaty.CheckedChanged += new System.EventHandler(this.cbxMeaty_CheckedChanged);
            // 
            // nudCalamari
            // 
            this.nudCalamari.Location = new System.Drawing.Point(171, 231);
            this.nudCalamari.Name = "nudCalamari";
            this.nudCalamari.Size = new System.Drawing.Size(53, 22);
            this.nudCalamari.TabIndex = 21;
         
            // 
            // nudThree
            // 
            this.nudThree.Location = new System.Drawing.Point(171, 192);
            this.nudThree.Name = "nudThree";
            this.nudThree.Size = new System.Drawing.Size(53, 22);
            this.nudThree.TabIndex = 20;
           
            // 
            // cbxCalamari
            // 
            this.cbxCalamari.AutoSize = true;
            this.cbxCalamari.Location = new System.Drawing.Point(18, 231);
            this.cbxCalamari.Name = "cbxCalamari";
            this.cbxCalamari.Size = new System.Drawing.Size(85, 17);
            this.cbxCalamari.TabIndex = 17;
            this.cbxCalamari.Text = "Calamari";
            this.cbxCalamari.UseVisualStyleBackColor = true;
            this.cbxCalamari.CheckedChanged += new System.EventHandler(this.cbxCalamari_CheckedChanged);
            // 
            // cbxThree
            // 
            this.cbxThree.AutoSize = true;
            this.cbxThree.Location = new System.Drawing.Point(18, 192);
            this.cbxThree.Name = "cbxThree";
            this.cbxThree.Size = new System.Drawing.Size(113, 17);
            this.cbxThree.TabIndex = 16;
            this.cbxThree.Text = "Three Cheese";
            this.cbxThree.UseVisualStyleBackColor = true;
            this.cbxThree.CheckedChanged += new System.EventHandler(this.cbxThree_CheckedChanged);
            // 
            // nudCAT
            // 
            this.nudCAT.Location = new System.Drawing.Point(215, 144);
            this.nudCAT.Name = "nudCAT";
            this.nudCAT.Size = new System.Drawing.Size(53, 22);
            this.nudCAT.TabIndex = 15;
          
            // nudCheese
            // 
            this.nudCheese.Location = new System.Drawing.Point(215, 105);
            this.nudCheese.Name = "nudCheese";
            this.nudCheese.Size = new System.Drawing.Size(53, 22);
            this.nudCheese.TabIndex = 14;
          
            // 
            // nudHAC
            // 
            this.nudHAC.Location = new System.Drawing.Point(215, 62);
            this.nudHAC.Name = "nudHAC";
            this.nudHAC.Size = new System.Drawing.Size(53, 22);
            this.nudHAC.TabIndex = 13;
          
            // 
            // nudChickMayo
            // 
            this.nudChickMayo.Location = new System.Drawing.Point(215, 23);
            this.nudChickMayo.Name = "nudChickMayo";
            this.nudChickMayo.Size = new System.Drawing.Size(53, 22);
            this.nudChickMayo.TabIndex = 12;
          
            // 
            // cbxCAT
            // 
            this.cbxCAT.AutoSize = true;
            this.cbxCAT.Location = new System.Drawing.Point(6, 146);
            this.cbxCAT.Name = "cbxCAT";
            this.cbxCAT.Size = new System.Drawing.Size(148, 17);
            this.cbxCAT.TabIndex = 11;
            this.cbxCAT.Text = "Cheese And Tomato";
            this.cbxCAT.UseVisualStyleBackColor = true;
            this.cbxCAT.CheckedChanged += new System.EventHandler(this.cbxCAT_CheckedChanged);
            // 
            // cbxCheese
            // 
            this.cbxCheese.AutoSize = true;
            this.cbxCheese.Location = new System.Drawing.Point(6, 106);
            this.cbxCheese.Name = "cbxCheese";
            this.cbxCheese.Size = new System.Drawing.Size(71, 17);
            this.cbxCheese.TabIndex = 10;
            this.cbxCheese.Text = "Cheese";
            this.cbxCheese.UseVisualStyleBackColor = true;
            this.cbxCheese.CheckedChanged += new System.EventHandler(this.cbxCheese_CheckedChanged);
            // 
            // cbxHAC
            // 
            this.cbxHAC.AutoSize = true;
            this.cbxHAC.Location = new System.Drawing.Point(6, 62);
            this.cbxHAC.Name = "cbxHAC";
            this.cbxHAC.Size = new System.Drawing.Size(127, 17);
            this.cbxHAC.TabIndex = 9;
            this.cbxHAC.Text = "Ham And Cheese";
            this.cbxHAC.UseVisualStyleBackColor = true;
            this.cbxHAC.CheckedChanged += new System.EventHandler(this.cbxHAC_CheckedChanged);
            // 
            // cbxChickMayo
            // 
            this.cbxChickMayo.AutoSize = true;
            this.cbxChickMayo.Location = new System.Drawing.Point(6, 23);
            this.cbxChickMayo.Name = "cbxChickMayo";
            this.cbxChickMayo.Size = new System.Drawing.Size(113, 17);
            this.cbxChickMayo.TabIndex = 8;
            this.cbxChickMayo.Text = "Chicken Mayo";
            this.cbxChickMayo.UseVisualStyleBackColor = true;
            this.cbxChickMayo.CheckedChanged += new System.EventHandler(this.cbxChickMayo_CheckedChanged);
            // 
            // nudMediteranean
            // 
            this.nudMediteranean.Location = new System.Drawing.Point(215, 266);
            this.nudMediteranean.Name = "nudMediteranean";
            this.nudMediteranean.Size = new System.Drawing.Size(53, 22);
            this.nudMediteranean.TabIndex = 22;
         
            // 
            // nudDagwood
            // 
            this.nudDagwood.Location = new System.Drawing.Point(215, 223);
            this.nudDagwood.Name = "nudDagwood";
            this.nudDagwood.Size = new System.Drawing.Size(53, 22);
            this.nudDagwood.TabIndex = 21;
           
            // 
            // nudHCT
            // 
            this.nudHCT.Location = new System.Drawing.Point(215, 184);
            this.nudHCT.Name = "nudHCT";
            this.nudHCT.Size = new System.Drawing.Size(53, 22);
            this.nudHCT.TabIndex = 20;
           
            // 
            // cbxMediter
            // 
            this.cbxMediter.AutoSize = true;
            this.cbxMediter.Location = new System.Drawing.Point(6, 267);
            this.cbxMediter.Name = "cbxMediter";
            this.cbxMediter.Size = new System.Drawing.Size(113, 17);
            this.cbxMediter.TabIndex = 18;
            this.cbxMediter.Text = "Mediteranean";
            this.cbxMediter.UseVisualStyleBackColor = true;
            this.cbxMediter.CheckedChanged += new System.EventHandler(this.cbxMediter_CheckedChanged);
            // 
            // cbxDagwood
            // 
            this.cbxDagwood.AutoSize = true;
            this.cbxDagwood.Location = new System.Drawing.Point(6, 223);
            this.cbxDagwood.Name = "cbxDagwood";
            this.cbxDagwood.Size = new System.Drawing.Size(78, 17);
            this.cbxDagwood.TabIndex = 17;
            this.cbxDagwood.Text = "Dagwood";
            this.cbxDagwood.UseVisualStyleBackColor = true;
            this.cbxDagwood.CheckedChanged += new System.EventHandler(this.cbxDagwood_CheckedChanged);
            // 
            // cbxHCT
            // 
            this.cbxHCT.AutoSize = true;
            this.cbxHCT.Location = new System.Drawing.Point(6, 184);
            this.cbxHCT.Name = "cbxHCT";
            this.cbxHCT.Size = new System.Drawing.Size(183, 17);
            this.cbxHCT.TabIndex = 16;
            this.cbxHCT.Text = "Ham, Cheese and Tomato";
            this.cbxHCT.UseVisualStyleBackColor = true;
            this.cbxHCT.CheckedChanged += new System.EventHandler(this.cbxHCT_CheckedChanged);
            // 
            // nudCoke
            // 
            this.nudCoke.Location = new System.Drawing.Point(141, 140);
            this.nudCoke.Name = "nudCoke";
            this.nudCoke.Size = new System.Drawing.Size(53, 22);
            this.nudCoke.TabIndex = 15;
           
            // 
            // cbxPepsi
            // 
            this.cbxPepsi.AutoSize = true;
            this.cbxPepsi.Location = new System.Drawing.Point(6, 56);
            this.cbxPepsi.Name = "cbxPepsi";
            this.cbxPepsi.Size = new System.Drawing.Size(64, 17);
            this.cbxPepsi.TabIndex = 9;
            this.cbxPepsi.Text = "Pepsi";
            this.cbxPepsi.UseVisualStyleBackColor = true;
            this.cbxPepsi.CheckedChanged += new System.EventHandler(this.cbxPepsi_CheckedChanged);
            // 
            // nudLemon
            // 
            this.nudLemon.Location = new System.Drawing.Point(141, 101);
            this.nudLemon.Name = "nudLemon";
            this.nudLemon.Size = new System.Drawing.Size(53, 22);
            this.nudLemon.TabIndex = 14;
          
            // 
            // cbxMD
            // 
            this.cbxMD.AutoSize = true;
            this.cbxMD.Location = new System.Drawing.Point(6, 20);
            this.cbxMD.Name = "cbxMD";
            this.cbxMD.Size = new System.Drawing.Size(113, 17);
            this.cbxMD.TabIndex = 8;
            this.cbxMD.Text = "Mountain Dew";
            this.cbxMD.UseVisualStyleBackColor = true;
            this.cbxMD.CheckedChanged += new System.EventHandler(this.cbxMD_CheckedChanged);
            // 
            // nudPepsi
            // 
            this.nudPepsi.Location = new System.Drawing.Point(141, 58);
            this.nudPepsi.Name = "nudPepsi";
            this.nudPepsi.Size = new System.Drawing.Size(53, 22);
            this.nudPepsi.TabIndex = 13;
            
            // 
            // cbxLemon
            // 
            this.cbxLemon.AutoSize = true;
            this.cbxLemon.Location = new System.Drawing.Point(6, 100);
            this.cbxLemon.Name = "cbxLemon";
            this.cbxLemon.Size = new System.Drawing.Size(85, 17);
            this.cbxLemon.TabIndex = 10;
            this.cbxLemon.Text = "Lemonade";
            this.cbxLemon.UseVisualStyleBackColor = true;
            this.cbxLemon.CheckedChanged += new System.EventHandler(this.cbxLemon_CheckedChanged);
            // 
            // nudMD
            // 
            this.nudMD.Location = new System.Drawing.Point(141, 19);
            this.nudMD.Name = "nudMD";
            this.nudMD.Size = new System.Drawing.Size(53, 22);
            this.nudMD.TabIndex = 12;
           
            // 
            // cbxCoke
            // 
            this.cbxCoke.AutoSize = true;
            this.cbxCoke.Location = new System.Drawing.Point(6, 140);
            this.cbxCoke.Name = "cbxCoke";
            this.cbxCoke.Size = new System.Drawing.Size(92, 17);
            this.cbxCoke.TabIndex = 11;
            this.cbxCoke.Text = "Coca-Cola";
            this.cbxCoke.UseVisualStyleBackColor = true;
            this.cbxCoke.CheckedChanged += new System.EventHandler(this.cbxCoke_CheckedChanged);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(794, 576);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(171, 44);
            this.btnClear.TabIndex = 8;
            this.btnClear.Text = "Clear Selection";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnPlaceOrder
            // 
            this.btnPlaceOrder.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlaceOrder.Location = new System.Drawing.Point(968, 576);
            this.btnPlaceOrder.Name = "btnPlaceOrder";
            this.btnPlaceOrder.Size = new System.Drawing.Size(171, 44);
            this.btnPlaceOrder.TabIndex = 9;
            this.btnPlaceOrder.Text = "Place Order";
            this.btnPlaceOrder.UseVisualStyleBackColor = true;
            this.btnPlaceOrder.Click += new System.EventHandler(this.btnPlaceOrder_Click);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Salmon;
            this.ClientSize = new System.Drawing.Size(1144, 632);
            this.Controls.Add(this.btnPlaceOrder);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMenu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudBigBoy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVeg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChicken)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRib)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChips)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHotdog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChickenNug)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBaby)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTenders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMashed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMargherita)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMayo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMeaty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCalamari)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudThree)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCAT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCheese)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHAC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChickMayo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMediteranean)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDagwood)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHCT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCoke)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLemon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPepsi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox cbxRib;
        private System.Windows.Forms.CheckBox cbxChicken;
        private System.Windows.Forms.CheckBox cbxVeg;
        private System.Windows.Forms.CheckBox cbxBigBoy;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.NumericUpDown nudRib;
        private System.Windows.Forms.NumericUpDown nudChicken;
        private System.Windows.Forms.NumericUpDown nudVeg;
        private System.Windows.Forms.NumericUpDown nudBigBoy;
        private System.Windows.Forms.NumericUpDown nudTenders;
        private System.Windows.Forms.NumericUpDown nudMashed;
        private System.Windows.Forms.CheckBox cbxTenders;
        private System.Windows.Forms.CheckBox cbxMashed;
        private System.Windows.Forms.NumericUpDown nudChips;
        private System.Windows.Forms.NumericUpDown nudHotdog;
        private System.Windows.Forms.NumericUpDown nudChickenNug;
        private System.Windows.Forms.NumericUpDown nudBaby;
        private System.Windows.Forms.CheckBox cbxChips;
        private System.Windows.Forms.CheckBox cbxHotdog;
        private System.Windows.Forms.CheckBox cbxChickenNug;
        private System.Windows.Forms.CheckBox cbxBaby;
        private System.Windows.Forms.NumericUpDown nudCalamari;
        private System.Windows.Forms.NumericUpDown nudThree;
        private System.Windows.Forms.CheckBox cbxCalamari;
        private System.Windows.Forms.CheckBox cbxThree;
        private System.Windows.Forms.NumericUpDown nudMargherita;
        private System.Windows.Forms.NumericUpDown nudFour;
        private System.Windows.Forms.NumericUpDown nudMayo;
        private System.Windows.Forms.NumericUpDown nudMeaty;
        private System.Windows.Forms.CheckBox cbxMargherita;
        private System.Windows.Forms.CheckBox cbxFour;
        private System.Windows.Forms.CheckBox cbxMayo;
        private System.Windows.Forms.CheckBox cbxMeaty;
        private System.Windows.Forms.NumericUpDown nudMediteranean;
        private System.Windows.Forms.NumericUpDown nudDagwood;
        private System.Windows.Forms.NumericUpDown nudHCT;
        private System.Windows.Forms.CheckBox cbxMediter;
        private System.Windows.Forms.CheckBox cbxDagwood;
        private System.Windows.Forms.CheckBox cbxHCT;
        private System.Windows.Forms.NumericUpDown nudCAT;
        private System.Windows.Forms.NumericUpDown nudCheese;
        private System.Windows.Forms.NumericUpDown nudHAC;
        private System.Windows.Forms.NumericUpDown nudChickMayo;
        private System.Windows.Forms.CheckBox cbxCAT;
        private System.Windows.Forms.CheckBox cbxCheese;
        private System.Windows.Forms.CheckBox cbxHAC;
        private System.Windows.Forms.CheckBox cbxChickMayo;
        private System.Windows.Forms.NumericUpDown nudCoke;
        private System.Windows.Forms.CheckBox cbxPepsi;
        private System.Windows.Forms.NumericUpDown nudLemon;
        private System.Windows.Forms.CheckBox cbxMD;
        private System.Windows.Forms.NumericUpDown nudPepsi;
        private System.Windows.Forms.CheckBox cbxLemon;
        private System.Windows.Forms.NumericUpDown nudMD;
        private System.Windows.Forms.CheckBox cbxCoke;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnPlaceOrder;
    }
}

