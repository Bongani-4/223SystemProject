﻿CREATE TABLE [dbo].[Users]
(
	[CustId] INT NOT NULL PRIMARY KEY, 
    [CustName] NCHAR(10) NULL, 
    [CustSurname] NCHAR(15) NULL, 
    [Password] NCHAR(10) NULL, 
    [CustEmail] NCHAR(20) NULL, 
    [isAdmin] INT NULL, 
    [Username] NCHAR(10) NULL
)
