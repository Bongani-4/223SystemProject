﻿CREATE TABLE [dbo].[Users]
(
	[CustomerId] INT NOT NULL PRIMARY KEY, 
    [CustomerNameSurname] NCHAR(30) NULL, 
    [Password] NCHAR(10) NULL, 
    [CustomerEmail] NCHAR(40) NULL, 
    [isAdmin] BINARY(50) NULL
)
