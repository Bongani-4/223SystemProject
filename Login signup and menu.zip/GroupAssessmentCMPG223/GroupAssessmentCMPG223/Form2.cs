﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupAssessmentCMPG223
{
    public partial class frmLoginAndSignup : Form
    {
        public frmLoginAndSignup()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\divan\source\repos\GroupAssessmentCMPG223\GroupAssessmentCMPG223\DBCustomers.mdf;Integrated Security=True");
        SqlCommand comm;
        SqlDataReader reader;
        SqlDataAdapter adapter;
        DataSet ds;
        bool registered = true;
        private void button2_Click(object sender, EventArgs e)
        {
            if (registered)
            {
                lblLoginSignup.Text = "Sign Up";

                lblEmail.Visible = true;
                tbxEmail.Visible = true;
                tbxEmail.Enabled = true;

                lblName.Visible = true;
                tbxName.Visible = true;
                tbxName.Enabled = true;

                lblSurname.Visible = true;
                tbxSurname.Visible = true;
                tbxSurname.Enabled = true;

                btnSignup.Enabled = false;
                btnSignup.Visible = false;

                lblRegistered.Visible = false;

                registered = false;
            }



        }

        private void frmLoginAndSignup_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (!registered)
            {
                string username = tbxUsername.Text;
                string password = tbxPassword.Text;
                string email = tbxEmail.Text;
                string name = tbxName.Text;
                string surname = tbxSurname.Text;

                int id = 0;


                try
                {
                    try
                    {
                        conn.Open();

                        string sqlr = "SELECT DISTINCT CustId FROM Users";

                        comm = new SqlCommand(sqlr, conn);

                        reader = comm.ExecuteReader();
                        while (reader.Read())
                        {
                            
                                id = int.Parse((reader.GetValue(0).ToString()))+1;
                        }

                        conn.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                    conn.Open();

                    string sql = "INSERT INTO Users(CustId,Username,CustEmail, CustName, CustSurname, Password) VALUES (@Id,@username,@email, @name, @surname, @password)";

                    comm = new SqlCommand(sql, conn);
                    comm.Parameters.AddWithValue("@Id", id);
                    comm.Parameters.AddWithValue("@name", name);
                    comm.Parameters.AddWithValue("@surname", surname);
                    comm.Parameters.AddWithValue("@username", username);
                    comm.Parameters.AddWithValue("@password", password);
                    comm.Parameters.AddWithValue("@email", email);

                    adapter = new SqlDataAdapter();
                    adapter.InsertCommand = comm;
                    adapter.InsertCommand.ExecuteNonQuery();

                    conn.Close();

                    MessageBox.Show("profile has been created");

                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                try
                {

                    string username = tbxUsername.Text;
                    string password = tbxPassword.Text;
                    string email = tbxEmail.Text;
                    string name = tbxName.Text;
                    conn.Open();

                    string sql = @"SELECT Password FROM Users WHERE CustUsername = '" + username + "'";
                    SqlCommand command = new SqlCommand(sql, conn);
                    object result = command.ExecuteScalar();


                    if (result != null && result.ToString() == password)
                    {
                        frmMenu db = new frmMenu();

                        db.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password.");
                    }
                    conn.Close();
                }


                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
    }
}
