﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectSystem
{
    public partial class frmReportMain : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\joshu\Desktop\CMPG 212\Projects\ProjectSystem\Report.mdf;Integrated Security=True;User Instance=True");
        SqlDataReader reader;
        DataSet dataSet = new DataSet();
        SqlDataAdapter adapter;
        SqlCommand command;
        public frmReportMain()
        {
            InitializeComponent();
        }

        private void btnSortD_Click(object sender, EventArgs e)
        {
            con.Open();
            try
            {
                MessageBox.Show("after this");
                SqlCommand sqlCommand = new SqlCommand(@"SELECT * FROM Order", con);
                adapter = new SqlDataAdapter();
                dataSet = new DataSet();

                adapter.SelectCommand = sqlCommand;
                adapter.Fill(dataSet, "Order");

                dgvOrders.DataSource = dataSet;
                dgvOrders.DataMember = "Order";
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnGetReport_Click(object sender, EventArgs e)
        {
            frmReportWin genReport = new frmReportWin();
            genReport.ShowDialog();
        }

        private void frmReportMain_Load(object sender, EventArgs e)
        {
            
        }
    }
}
