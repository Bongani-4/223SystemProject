﻿CREATE TABLE [dbo].[Order] (
    [Order_ID]   INT      NOT NULL,
    [User_ID]    INT      NULL,
    [OrderDate]  DATETIME NULL,
    [OrderItems] TEXT     NULL,
    [Payment_ID] INT      NULL,
    PRIMARY KEY CLUSTERED ([Order_ID] ASC)
);