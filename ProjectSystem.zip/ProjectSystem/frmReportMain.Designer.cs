﻿namespace ProjectSystem
{
    partial class frmReportMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picCompanyLogo = new System.Windows.Forms.PictureBox();
            this.dgvOrders = new System.Windows.Forms.DataGridView();
            this.dgvMenu = new System.Windows.Forms.DataGridView();
            this.btnGetReport = new System.Windows.Forms.Button();
            this.btnSMenuItem = new System.Windows.Forms.Button();
            this.btnSortD = new System.Windows.Forms.Button();
            this.btnSortA = new System.Windows.Forms.Button();
            this.txtSOrder = new System.Windows.Forms.TextBox();
            this.btnSOrder = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSMenu = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picCompanyLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMenu)).BeginInit();
            this.SuspendLayout();
            // 
            // picCompanyLogo
            // 
            this.picCompanyLogo.Image = global::ProjectSystem.Properties.Resources.Logo;
            this.picCompanyLogo.Location = new System.Drawing.Point(177, 10);
            this.picCompanyLogo.Margin = new System.Windows.Forms.Padding(2);
            this.picCompanyLogo.Name = "picCompanyLogo";
            this.picCompanyLogo.Size = new System.Drawing.Size(110, 105);
            this.picCompanyLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCompanyLogo.TabIndex = 0;
            this.picCompanyLogo.TabStop = false;
            // 
            // dgvOrders
            // 
            this.dgvOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrders.Location = new System.Drawing.Point(9, 140);
            this.dgvOrders.Margin = new System.Windows.Forms.Padding(2);
            this.dgvOrders.Name = "dgvOrders";
            this.dgvOrders.RowHeadersWidth = 51;
            this.dgvOrders.RowTemplate.Height = 24;
            this.dgvOrders.Size = new System.Drawing.Size(459, 221);
            this.dgvOrders.TabIndex = 1;
            // 
            // dgvMenu
            // 
            this.dgvMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMenu.Location = new System.Drawing.Point(536, 140);
            this.dgvMenu.Margin = new System.Windows.Forms.Padding(2);
            this.dgvMenu.Name = "dgvMenu";
            this.dgvMenu.RowHeadersWidth = 51;
            this.dgvMenu.RowTemplate.Height = 24;
            this.dgvMenu.Size = new System.Drawing.Size(459, 221);
            this.dgvMenu.TabIndex = 2;
            // 
            // btnGetReport
            // 
            this.btnGetReport.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetReport.Location = new System.Drawing.Point(153, 479);
            this.btnGetReport.Margin = new System.Windows.Forms.Padding(2);
            this.btnGetReport.Name = "btnGetReport";
            this.btnGetReport.Size = new System.Drawing.Size(172, 50);
            this.btnGetReport.TabIndex = 8;
            this.btnGetReport.Text = "Generate Report";
            this.btnGetReport.UseVisualStyleBackColor = true;
            this.btnGetReport.Click += new System.EventHandler(this.btnGetReport_Click);
            // 
            // btnSMenuItem
            // 
            this.btnSMenuItem.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSMenuItem.Location = new System.Drawing.Point(824, 454);
            this.btnSMenuItem.Margin = new System.Windows.Forms.Padding(2);
            this.btnSMenuItem.Name = "btnSMenuItem";
            this.btnSMenuItem.Size = new System.Drawing.Size(172, 50);
            this.btnSMenuItem.TabIndex = 9;
            this.btnSMenuItem.Text = "Search menu item";
            this.btnSMenuItem.UseVisualStyleBackColor = true;
            // 
            // btnSortD
            // 
            this.btnSortD.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSortD.Location = new System.Drawing.Point(296, 388);
            this.btnSortD.Margin = new System.Windows.Forms.Padding(2);
            this.btnSortD.Name = "btnSortD";
            this.btnSortD.Size = new System.Drawing.Size(172, 50);
            this.btnSortD.TabIndex = 10;
            this.btnSortD.Text = "Sort Descending";
            this.btnSortD.UseVisualStyleBackColor = true;
            this.btnSortD.Click += new System.EventHandler(this.btnSortD_Click);
            // 
            // btnSortA
            // 
            this.btnSortA.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSortA.Location = new System.Drawing.Point(9, 388);
            this.btnSortA.Margin = new System.Windows.Forms.Padding(2);
            this.btnSortA.Name = "btnSortA";
            this.btnSortA.Size = new System.Drawing.Size(172, 50);
            this.btnSortA.TabIndex = 11;
            this.btnSortA.Text = "Sort Ascending";
            this.btnSortA.UseVisualStyleBackColor = true;
            // 
            // txtSOrder
            // 
            this.txtSOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSOrder.Location = new System.Drawing.Point(536, 403);
            this.txtSOrder.Margin = new System.Windows.Forms.Padding(2);
            this.txtSOrder.Name = "txtSOrder";
            this.txtSOrder.Size = new System.Drawing.Size(248, 23);
            this.txtSOrder.TabIndex = 12;
            // 
            // btnSOrder
            // 
            this.btnSOrder.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSOrder.Location = new System.Drawing.Point(824, 388);
            this.btnSOrder.Margin = new System.Windows.Forms.Padding(2);
            this.btnSOrder.Name = "btnSOrder";
            this.btnSOrder.Size = new System.Drawing.Size(172, 50);
            this.btnSOrder.TabIndex = 13;
            this.btnSOrder.Text = "Search order";
            this.btnSOrder.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SimSun", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(452, 50);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 33);
            this.label1.TabIndex = 14;
            this.label1.Text = "Report";
            // 
            // txtSMenu
            // 
            this.txtSMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSMenu.Location = new System.Drawing.Point(536, 469);
            this.txtSMenu.Margin = new System.Windows.Forms.Padding(2);
            this.txtSMenu.Name = "txtSMenu";
            this.txtSMenu.Size = new System.Drawing.Size(248, 23);
            this.txtSMenu.TabIndex = 15;
            // 
            // frmReportMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Salmon;
            this.ClientSize = new System.Drawing.Size(1004, 544);
            this.Controls.Add(this.txtSMenu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSOrder);
            this.Controls.Add(this.txtSOrder);
            this.Controls.Add(this.btnSortA);
            this.Controls.Add(this.btnSortD);
            this.Controls.Add(this.btnSMenuItem);
            this.Controls.Add(this.btnGetReport);
            this.Controls.Add(this.dgvMenu);
            this.Controls.Add(this.dgvOrders);
            this.Controls.Add(this.picCompanyLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmReportMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Report";
            this.Load += new System.EventHandler(this.frmReportMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picCompanyLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMenu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picCompanyLogo;
        private System.Windows.Forms.DataGridView dgvOrders;
        private System.Windows.Forms.DataGridView dgvMenu;
        private System.Windows.Forms.Button btnGetReport;
        private System.Windows.Forms.Button btnSMenuItem;
        private System.Windows.Forms.Button btnSortD;
        private System.Windows.Forms.Button btnSortA;
        private System.Windows.Forms.TextBox txtSOrder;
        private System.Windows.Forms.Button btnSOrder;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSMenu;
    }
}

