﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AddStock : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\botes\OneDrive\Desktop\WindowsFormsApp1\Stock.mdf;Integrated Security=True;User Instance=True");
        SqlDataReader reader;
        DataSet dataSet;
        SqlDataAdapter adapter;
        SqlCommand command;
        public AddStock()
        {
            InitializeComponent();
        }

        private void AddStock_Load(object sender, EventArgs e)
        {
            con.Open();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAddStock_Click(object sender, EventArgs e)
        {
            try
            {
                string name = tbName.Text;
                int supplierId = int.Parse(tbSupplier.Text);
                int quantity = int.Parse(tbQuantity.Text);
                int id = int.Parse(tbId.Text);

                string sql = $"INSERT INTO Stock (Id, Name, SupplierId, Quantity) VALUES ({id}, '{name}', {supplierId}, {quantity})";
                command = new SqlCommand(sql, con);
                command.ExecuteNonQuery();

                MessageBox.Show("Stock added successfully.");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Error: " + ex.Message);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
