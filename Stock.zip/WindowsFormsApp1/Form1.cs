﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\botes\OneDrive\Desktop\WindowsFormsApp1\Stock.mdf;Integrated Security=True;User Instance=True");
        SqlDataReader reader;
        DataSet dataSet;
        SqlDataAdapter adapter;
        SqlCommand command;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach(Control ctr in this.Controls)
            {
                if( ctr is MdiClient)
                {
                    ctr.BackColor = Color.Salmon;
                }
            }

            con.Open();
            try
            {
                SqlCommand sqlCommand = new SqlCommand(@"SELECT * FROM Stock", con);
                adapter = new SqlDataAdapter();
                dataSet = new DataSet();

                adapter.SelectCommand = sqlCommand;
                adapter.Fill(dataSet, "Stock");

                dgv1.DataSource = dataSet;
                dgv1.DataMember = "Stock";
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnAddStock_Click(object sender, EventArgs e)
        {
            AddStock AddStock = new AddStock();
            AddStock.MdiParent = this.MdiParent; // "this" is Form1
            AddStock.Show();
        }

        private void btnRF_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand sqlCommand = new SqlCommand(@"SELECT * FROM Stock", con);
                adapter = new SqlDataAdapter();
                dataSet = new DataSet();

                adapter.SelectCommand = sqlCommand;
                adapter.Fill(dataSet, "Stock");

                dgv1.DataSource = dataSet;
                dgv1.DataMember = "Stock";
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            command = new SqlCommand($"Select * from Stock where Name Like '%{tbSearch.Text}%'", con);
            adapter = new SqlDataAdapter();
            dataSet = new DataSet();

            adapter.SelectCommand = command;
            adapter.Fill(dataSet, "Punte");

            dgv1.DataSource = dataSet;
            dgv1.DataMember = "Punte";
        }
    }
}
